from django.apps import AppConfig


class OsClientConfig(AppConfig):
    name = 'os_client'
