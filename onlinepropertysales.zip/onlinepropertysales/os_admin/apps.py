from django.apps import AppConfig


class OsAdminConfig(AppConfig):
    name = 'os_admin'
