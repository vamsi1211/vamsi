from django.apps import AppConfig


class OsMainConfig(AppConfig):
    name = 'os_main'
