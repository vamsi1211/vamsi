from django.apps import AppConfig


class OsAgentConfig(AppConfig):
    name = 'os_agent'
