from django.apps import AppConfig


class ExampleppConfig(AppConfig):
    name = 'examplepp'
